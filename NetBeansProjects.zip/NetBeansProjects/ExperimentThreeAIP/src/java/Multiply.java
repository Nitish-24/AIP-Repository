/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Nitish
 */
@WebServlet(urlPatterns = {"/Multiply"})
public class Multiply extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int sum = (int) request.getAttribute("sum");

        // perform the average operation and  
        // save the result in 'avg' variable. 
        int mult = 5 * 10;

        // Get the PrintWriter object to write  
        // the output in the response to the browser. 
        PrintWriter out = response.getWriter();
        out.println("Sum is: " + sum);
        out.println("Multiplication is: " + mult);

    }

}
