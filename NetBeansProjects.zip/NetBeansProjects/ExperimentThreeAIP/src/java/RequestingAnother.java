/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Nitish
 */
@WebServlet(urlPatterns = {"/RequestingAnother"})
public class RequestingAnother extends HttpServlet {

 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      int num1 = Integer.parseInt(request.getParameter("Fsvalue")); 
        int num2 = Integer.parseInt(request.getParameter("Svalue")); 
  
        // Perform addition operation on num1, num2 
        // and save the result in add variable. 
        int add = num1 + num2; 
          
        // Set the add value in 'sum'  
        // attribute of request object 
        request.setAttribute("sum", add); 
  
        // Get the Request Dispatcher object and pass  s
        // the argument to which servlet we need to call - AvgNum.java 
        RequestDispatcher reqd = request.getRequestDispatcher("Multiply"); 
        
        // Forward the Request Dispatcher object. 
        reqd.forward(request, response); 
    }

  

}
